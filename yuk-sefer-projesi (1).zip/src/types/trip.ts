export type TripStatus = 'Yolda' | 'Teslim Edildi' | 'Faturalandı' | 'Ödeme Bekliyor' | 'Tamamlandı';

export interface TripExpense {
  fuelCost: number;
  fuelLiters?: number;
  tollCost: number; // HGS & OGS
  foodAllowanceCost: number; // Harcırah / Yemek
  maintenanceCost: number; // Tamir / Lastik
  otherCosts: number; // Hamaliye, Komisyon, Otopark vb.
}

export interface Trip {
  id: string;
  plate: string;
  driverName?: string;
  departureCity: string;
  destinationCity: string;
  cargoType: string;
  weightTons: number;
  distanceKm: number;
  freightRevenue: number;
  expenses: TripExpense;
  notes?: string;
  invoiceNumber?: string;
  status: TripStatus;
  date: string;
  createdAt: number;
}

export interface AdMobIds {
  banner: string;
  interstitial: string;
  rewarded: string;
}

export type AdMode = 'test' | 'production';

export interface AdMobState {
  mode: AdMode;
  isNative: boolean;
  initialized: boolean;
  bannerVisible: boolean;
  interstitialReady: boolean;
  rewardedReady: boolean;
  lastInterstitialAt: number;
  statusMessage: string;
  rewardTokens: number;
  bypassFrequencyCap: boolean;
}
