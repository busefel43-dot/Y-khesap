import React, { useState } from 'react';
import { Smartphone, Sparkles, ChevronDown, ChevronUp, ExternalLink, ShieldCheck } from 'lucide-react';
import { AdMode } from '../types/trip';

interface AdMobSimulatorBarProps {
  bannerId: string;
  mode: AdMode;
  isNative: boolean;
  onOpenControlPanel: () => void;
}

export const AdMobSimulatorBar: React.FC<AdMobSimulatorBarProps> = ({
  bannerId,
  mode,
  isNative,
  onOpenControlPanel,
}) => {
  const [collapsed, setCollapsed] = useState(false);

  if (isNative) {
    // In native mode, the native AdMob SDK renders the real banner at the bottom.
    return (
      <div className="fixed bottom-0 left-0 right-0 z-40 bg-slate-950/90 border-t border-slate-800 text-center py-1 text-[11px] text-emerald-400">
        Native AdMob Banner aktif (Android SDK)
      </div>
    );
  }

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 flex flex-col items-center pointer-events-none">
      <div className="w-full max-w-2xl px-2 pb-1 pointer-events-auto">
        <div className="overflow-hidden rounded-t-xl border-t border-x border-slate-700 bg-slate-900/95 shadow-2xl backdrop-blur-md">
          {/* Header Strip */}
          <div className="flex items-center justify-between border-b border-slate-800/80 bg-slate-950/80 px-3 py-1 text-[11px]">
            <div className="flex items-center gap-1.5">
              <span className="flex h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="font-semibold text-slate-300">
                AdMob Adaptive Banner ({mode.toUpperCase()})
              </span>
              <span className="rounded bg-slate-800 px-1 py-0.2 text-[10px] text-slate-400 font-mono">
                BOTTOM_CENTER
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={onOpenControlPanel}
                className="text-amber-400 hover:text-amber-300 font-medium underline text-[11px]"
              >
                Ayarlar
              </button>
              <button
                onClick={() => setCollapsed(!collapsed)}
                className="text-slate-400 hover:text-white p-0.5"
                title={collapsed ? 'Genişlet' : 'Küçült'}
              >
                {collapsed ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
              </button>
            </div>
          </div>

          {/* Banner Ad Content (Standard Google Adaptive Banner height 50-60px) */}
          {!collapsed && (
            <div className="relative flex items-center justify-between bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 px-4 py-2 hover:bg-slate-800/50 transition-colors">
              <div className="flex items-center gap-3">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-400">
                  <Smartphone className="h-5 w-5" />
                </div>
                <div className="text-left">
                  <div className="flex items-center gap-2">
                    <span className="rounded bg-amber-500/20 px-1 text-[9px] font-bold text-amber-300 border border-amber-500/30">
                      REKLAM
                    </span>
                    <h4 className="text-xs font-bold text-slate-100">
                      Opet & Shell Taşıt Tanıma İndirimi
                    </h4>
                  </div>
                  <p className="text-[11px] text-slate-400 line-clamp-1">
                    Mazotta kuruş hesabı yapan şoförlere özel %6 indirim fırsatı.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0 ml-2">
                <a
                  href="https://admob.google.com"
                  target="_blank"
                  rel="noreferrer"
                  className="rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-3 py-1.5 text-xs shadow transition-all active:scale-95 flex items-center gap-1"
                >
                  <span>Gör</span>
                  <ExternalLink className="h-3 w-3" />
                </a>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
