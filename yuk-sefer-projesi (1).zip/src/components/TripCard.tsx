import React, { useState } from 'react';
import {
  Truck,
  MapPin,
  Calendar,
  Share2,
  Trash2,
  Edit2,
  ChevronRight,
  Fuel,
  Receipt,
  CheckCircle2,
  Clock,
  Send,
  Check,
} from 'lucide-react';
import { Trip } from '../types/trip';
import {
  calculateTotalExpense,
  calculateNetProfit,
  formatTL,
  generateTripWhatsAppText,
} from '../utils/storage';

interface TripCardProps {
  trip: Trip;
  onEdit: (trip: Trip) => void;
  onDelete: (id: string) => void;
}

export const TripCard: React.FC<TripCardProps> = ({ trip, onEdit, onDelete }) => {
  const [copied, setCopied] = useState(false);
  const totalExpense = calculateTotalExpense(trip.expenses);
  const netProfit = calculateNetProfit(trip);
  const margin = trip.freightRevenue > 0 ? ((netProfit / trip.freightRevenue) * 100).toFixed(1) : '0';

  const handleShareWhatsApp = () => {
    const text = generateTripWhatsAppText(trip);
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);

    // Also offer direct WhatsApp web link
    const url = `https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  const getStatusBadge = (status: Trip['status']) => {
    switch (status) {
      case 'Yolda':
        return 'bg-blue-500/10 text-blue-400 border-blue-500/30';
      case 'Teslim Edildi':
        return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30';
      case 'Faturalandı':
        return 'bg-purple-500/10 text-purple-400 border-purple-500/30';
      case 'Ödeme Bekliyor':
        return 'bg-amber-500/10 text-amber-400 border-amber-500/30';
      case 'Tamamlandı':
        return 'bg-slate-700/50 text-slate-300 border-slate-600/50';
      default:
        return 'bg-slate-800 text-slate-300 border-slate-700';
    }
  };

  return (
    <div className="rounded-2xl border border-slate-800 bg-slate-900/80 hover:border-slate-700 transition-all shadow-lg overflow-hidden flex flex-col justify-between">
      {/* Top Bar */}
      <div className="border-b border-slate-800/80 bg-slate-950/60 px-4 py-3 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          {/* TR Plate Mockup */}
          <div className="flex items-center rounded-md bg-slate-100 border border-slate-300 px-1.5 py-0.5 text-xs font-black text-slate-900 font-mono tracking-wider shadow-sm">
            <span className="bg-blue-700 text-white text-[9px] px-1 py-0.5 rounded -ml-1 mr-1.5 font-bold">TR</span>
            <span>{trip.plate}</span>
          </div>

          {trip.driverName && (
            <span className="text-xs text-slate-400 truncate max-w-[120px]">
              {trip.driverName}
            </span>
          )}
        </div>

        <div className="flex items-center gap-2">
          <span
            className={`rounded-full px-2.5 py-0.5 text-[11px] font-semibold border ${getStatusBadge(
              trip.status
            )}`}
          >
            {trip.status}
          </span>
          <span className="text-xs text-slate-400 font-mono">{trip.date}</span>
        </div>
      </div>

      {/* Route & Cargo Content */}
      <div className="p-4 space-y-3">
        {/* Origin -> Destination Route */}
        <div className="flex items-center gap-2 text-sm font-bold text-white">
          <div className="flex items-center gap-1.5 truncate">
            <MapPin className="h-4 w-4 text-emerald-400 shrink-0" />
            <span className="truncate">{trip.departureCity}</span>
          </div>
          <ChevronRight className="h-4 w-4 text-slate-500 shrink-0" />
          <div className="flex items-center gap-1.5 truncate">
            <MapPin className="h-4 w-4 text-rose-400 shrink-0" />
            <span className="truncate">{trip.destinationCity}</span>
          </div>
        </div>

        {/* Cargo, Tonage, Distance Badges */}
        <div className="flex flex-wrap gap-2 text-xs">
          <span className="rounded-lg bg-slate-950 px-2.5 py-1 text-slate-300 border border-slate-800">
            📦 {trip.cargoType}
          </span>
          <span className="rounded-lg bg-slate-950 px-2.5 py-1 text-slate-300 border border-slate-800">
            ⚖️ {trip.weightTons} Ton
          </span>
          <span className="rounded-lg bg-slate-950 px-2.5 py-1 text-slate-300 border border-slate-800">
            🛣️ {trip.distanceKm} Km
          </span>
          {trip.invoiceNumber && (
            <span className="rounded-lg bg-slate-950 px-2.5 py-1 text-slate-400 font-mono border border-slate-800">
              #{trip.invoiceNumber}
            </span>
          )}
        </div>

        {/* Financial Breakdown Grid */}
        <div className="rounded-xl border border-slate-800/80 bg-slate-950/70 p-3 grid grid-cols-3 gap-2 text-center">
          <div>
            <span className="text-[10px] uppercase font-semibold text-slate-400 block">Navlun</span>
            <span className="text-sm font-bold font-mono text-emerald-400">
              {formatTL(trip.freightRevenue)}
            </span>
          </div>

          <div>
            <span className="text-[10px] uppercase font-semibold text-slate-400 block">Gider</span>
            <span className="text-sm font-bold font-mono text-rose-400">
              {formatTL(totalExpense)}
            </span>
          </div>

          <div>
            <span className="text-[10px] uppercase font-semibold text-slate-400 block">Net Kâr</span>
            <span
              className={`text-sm font-extrabold font-mono ${
                netProfit >= 0 ? 'text-amber-400' : 'text-rose-500'
              }`}
            >
              {formatTL(netProfit)}
            </span>
            <span className="text-[10px] text-slate-400 block">(%{margin})</span>
          </div>
        </div>

        {/* Notes preview if any */}
        {trip.notes && (
          <p className="text-xs text-slate-400 line-clamp-1 italic bg-slate-950/40 p-1.5 rounded">
            "{trip.notes}"
          </p>
        )}
      </div>

      {/* Card Footer Actions */}
      <div className="border-t border-slate-800/80 bg-slate-950/40 px-4 py-2.5 flex items-center justify-between">
        <button
          onClick={handleShareWhatsApp}
          className="flex items-center gap-1.5 text-xs font-semibold text-emerald-400 hover:text-emerald-300 transition-colors"
          title="WhatsApp Pusula Formatında Paylaş"
        >
          {copied ? (
            <>
              <Check className="h-3.5 w-3.5 text-emerald-400" />
              <span>Kopyalandı & Açıldı</span>
            </>
          ) : (
            <>
              <Share2 className="h-3.5 w-3.5" />
              <span>WhatsApp Pusula</span>
            </>
          )}
        </button>

        <div className="flex items-center gap-1">
          <button
            onClick={() => onEdit(trip)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            title="Düzenle"
          >
            <Edit2 className="h-4 w-4" />
          </button>
          <button
            onClick={() => {
              if (confirm(`${trip.plate} plakalı sefer silinsin mi?`)) {
                onDelete(trip.id);
              }
            }}
            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition-colors"
            title="Sil"
          >
            <Trash2 className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
