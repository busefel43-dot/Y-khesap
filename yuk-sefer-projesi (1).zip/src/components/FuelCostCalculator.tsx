import React, { useState } from 'react';
import { Fuel, Calculator, Award, Sparkles, TrendingUp, ShieldCheck, Check } from 'lucide-react';
import { formatTL } from '../utils/storage';
import { admobService } from '../services/admobService';

interface FuelCostCalculatorProps {
  rewardTokens: number;
}

export const FuelCostCalculator: React.FC<FuelCostCalculatorProps> = ({ rewardTokens }) => {
  const [km, setKm] = useState<number>(450);
  const [consumptionRate, setConsumptionRate] = useState<number>(32); // Litre / 100 km (yüklü tır)
  const [dieselPrice, setDieselPrice] = useState<number>(44.85); // ₺ / Litre
  const [tollEstimate, setTollEstimate] = useState<number>(1350); // HGS
  const [driverDailyAllowance, setDriverDailyAllowance] = useState<number>(850);
  const [targetMarginPercent, setTargetMarginPercent] = useState<number>(25); // %25 Kâr
  const [vipReportUnlocked, setVipReportUnlocked] = useState<boolean>(false);

  // Calculations
  const totalLiters = (km / 100) * consumptionRate;
  const totalFuelCost = totalLiters * dieselPrice;
  const totalTripCost = totalFuelCost + tollEstimate + driverDailyAllowance;
  
  // Recommended Freight Quote to achieve target profit margin
  // Freight - Cost = Margin * Freight => Freight * (1 - Margin/100) = Cost => Freight = Cost / (1 - Margin/100)
  const marginDecimal = targetMarginPercent / 100;
  const recommendedFreight = marginDecimal < 1 ? totalTripCost / (1 - marginDecimal) : totalTripCost * 1.5;
  const projectedProfit = recommendedFreight - totalTripCost;
  const costPerKm = km > 0 ? totalTripCost / km : 0;
  const freightPerKm = km > 0 ? recommendedFreight / km : 0;

  const handleUnlockVipReport = () => {
    if (rewardTokens > 0) {
      if (admobService.spendRewardToken(1)) {
        setVipReportUnlocked(true);
      }
    } else {
      // Trigger Rewarded Ad using admobService
      void admobService.showRewardedAd();
    }
  };

  return (
    <div className="rounded-2xl border border-slate-700 bg-slate-900/90 p-5 shadow-xl space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400">
            <Calculator className="h-6 w-6" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">Akaryakıt & Minimum Navlun Hesaplayıcı</h3>
            <p className="text-xs text-slate-400">
              Mesafe ve mazot giderine göre müşteriye zarar etmeden verilecek teklif tutarını hesaplayın.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 rounded-xl bg-slate-950 px-3 py-1.5 border border-slate-800">
          <Award className="h-4 w-4 text-amber-400" />
          <span className="text-xs text-slate-300 font-medium">Bakiye:</span>
          <span className="text-xs font-bold font-mono text-amber-400">{rewardTokens} VIP Jeton</span>
        </div>
      </div>

      {/* Input Sliders & Fields */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div>
          <label className="block text-xs font-medium text-slate-300 mb-1">
            Sefer Mesafesi: <span className="text-amber-400 font-bold">{km} km</span>
          </label>
          <input
            type="range"
            min="50"
            max="2500"
            step="25"
            value={km}
            onChange={(e) => setKm(Number(e.target.value))}
            className="w-full accent-amber-500"
          />
          <input
            type="number"
            min="10"
            value={km}
            onChange={(e) => setKm(Number(e.target.value))}
            className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-950 px-2.5 py-1.5 text-xs text-white"
          />
        </div>

        <div>
          <label className="block text-xs font-medium text-slate-300 mb-1">
            100 km Tüketim: <span className="text-amber-400 font-bold">{consumptionRate} Lt</span>
          </label>
          <input
            type="range"
            min="20"
            max="45"
            step="0.5"
            value={consumptionRate}
            onChange={(e) => setConsumptionRate(Number(e.target.value))}
            className="w-full accent-amber-500"
          />
          <div className="mt-1 flex items-center justify-between text-[11px] text-slate-400">
            <span>Boş: ~24 L</span>
            <span>Normal: ~30 L</span>
            <span>Ağır: ~35+ L</span>
          </div>
        </div>

        <div>
          <label className="block text-xs font-medium text-slate-300 mb-1">
            Motorin / Mazot Fiyatı (₺/Lt)
          </label>
          <input
            type="number"
            step="0.1"
            value={dieselPrice}
            onChange={(e) => setDieselPrice(Number(e.target.value))}
            className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white font-mono"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div>
          <label className="block text-xs font-medium text-slate-300 mb-1">Köprü & Otoyol (HGS) Tahmini</label>
          <input
            type="number"
            value={tollEstimate}
            onChange={(e) => setTollEstimate(Number(e.target.value))}
            className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white font-mono"
          />
        </div>

        <div>
          <label className="block text-xs font-medium text-slate-300 mb-1">Şoför Harcırahı & Yemek</label>
          <input
            type="number"
            value={driverDailyAllowance}
            onChange={(e) => setDriverDailyAllowance(Number(e.target.value))}
            className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white font-mono"
          />
        </div>

        <div>
          <label className="block text-xs font-medium text-slate-300 mb-1">
            Hedeflenen Kâr Marjı: <span className="text-emerald-400 font-bold">%{targetMarginPercent}</span>
          </label>
          <input
            type="range"
            min="10"
            max="50"
            step="5"
            value={targetMarginPercent}
            onChange={(e) => setTargetMarginPercent(Number(e.target.value))}
            className="w-full accent-emerald-500"
          />
        </div>
      </div>

      {/* Result Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="rounded-xl border border-slate-800 bg-slate-950 p-3.5">
          <span className="text-xs text-slate-400 block mb-1">Toplam Yakılacak Mazot</span>
          <div className="flex items-baseline gap-2">
            <span className="text-xl font-bold font-mono text-amber-400">{totalLiters.toFixed(0)} Lt</span>
            <span className="text-xs text-slate-400">({formatTL(totalFuelCost)})</span>
          </div>
          <span className="text-[11px] text-slate-400 block mt-1">KM Başına Yakıt: {(totalFuelCost / (km || 1)).toFixed(2)} ₺</span>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-950 p-3.5">
          <span className="text-xs text-slate-400 block mb-1">Başa Baş Maliyet (Zarar Noktası)</span>
          <div className="text-xl font-bold font-mono text-rose-400">
            {formatTL(totalTripCost)}
          </div>
          <span className="text-[11px] text-slate-400 block mt-1">Bu tutarın altı cepten gider</span>
        </div>

        <div className="rounded-xl border border-emerald-500/30 bg-emerald-500/10 p-3.5">
          <span className="text-xs text-emerald-400 font-bold block mb-1">
            Tavsiye Edilen Asgari Navlun
          </span>
          <div className="text-xl font-extrabold font-mono text-emerald-300">
            {formatTL(recommendedFreight)}
          </div>
          <span className="text-[11px] text-emerald-400/80 block mt-1">
            Net Hedef Kâr: +{formatTL(projectedProfit)}
          </span>
        </div>
      </div>

      {/* VIP Report Section (Rewarded ad incentive) */}
      <div className="rounded-xl border border-amber-500/30 bg-amber-500/5 p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-amber-400" />
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">
              {vipReportUnlocked ? 'VIP Sefer & Akaryakıt Analizi Açık' : 'VIP Rota & Ton/KM Maliyet Analizi'}
            </h4>
          </div>
          <p className="text-xs text-slate-300 mt-1 max-w-lg leading-relaxed">
            {vipReportUnlocked
              ? 'Ton/KM katsayısı, Osmangazi/Köprü alternatif rotaları ve amortisman payı aşağıda listelenmiştir.'
              : 'Ödüllü AdMob reklamını izleyerek veya 1 VIP Jeton harcayarak ayrıntılı rota maliyet tablosunu açın.'}
          </p>
        </div>

        {!vipReportUnlocked ? (
          <button
            onClick={handleUnlockVipReport}
            className="shrink-0 flex items-center gap-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:brightness-110 active:scale-95 px-4 py-2 text-xs font-bold text-slate-950 shadow-md transition-all"
          >
            <Award className="h-4 w-4" />
            <span>{rewardTokens > 0 ? '1 Jetonla Aç' : 'Reklam İzle & Kilidi Aç'}</span>
          </button>
        ) : (
          <div className="flex items-center gap-1.5 rounded-lg bg-emerald-500/20 px-3 py-1.5 text-xs font-bold text-emerald-400 border border-emerald-500/30">
            <Check className="h-4 w-4" />
            <span>Kilidi Açıldı</span>
          </div>
        )}
      </div>

      {/* VIP Expanded Details */}
      {vipReportUnlocked && (
        <div className="rounded-xl border border-slate-800 bg-slate-950 p-4 space-y-3 animate-in fade-in duration-300">
          <h5 className="text-xs font-bold text-amber-400 uppercase">Detaylı Lojistik Katsayıları:</h5>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div className="rounded-lg bg-slate-900 p-2.5">
              <span className="text-slate-400 block text-[11px]">KM Başına Tam Maliyet</span>
              <span className="font-bold text-slate-200 font-mono text-sm">{costPerKm.toFixed(2)} ₺/km</span>
            </div>
            <div className="rounded-lg bg-slate-900 p-2.5">
              <span className="text-slate-400 block text-[11px]">KM Başına Önerilen Fiyat</span>
              <span className="font-bold text-emerald-400 font-mono text-sm">{freightPerKm.toFixed(2)} ₺/km</span>
            </div>
            <div className="rounded-lg bg-slate-900 p-2.5">
              <span className="text-slate-400 block text-[11px]">Lastik & Bakım Payı (Önerilen)</span>
              <span className="font-bold text-slate-200 font-mono text-sm">{(km * 2.2).toFixed(0)} ₺</span>
            </div>
            <div className="rounded-lg bg-slate-900 p-2.5">
              <span className="text-slate-400 block text-[11px]">Vergi & Bağkur Amortismanı</span>
              <span className="font-bold text-slate-200 font-mono text-sm">{(km * 1.5).toFixed(0)} ₺</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
