import React, { useEffect, useState } from 'react';
import { X, Volume2, VolumeX, Award, ShieldAlert, CheckCircle2, Play } from 'lucide-react';
import confetti from 'canvas-confetti';
import { admobService } from '../services/admobService';

interface AdMobModalProps {
  type: 'interstitial' | 'rewarded';
  adId: string;
  isTestMode: boolean;
  onClose: (rewardEarned?: boolean) => void;
}

export const AdMobModal: React.FC<AdMobModalProps> = ({
  type,
  adId,
  isTestMode,
  onClose,
}) => {
  const [secondsLeft, setSecondsLeft] = useState(type === 'rewarded' ? 5 : 4);
  const [canClose, setCanClose] = useState(type === 'interstitial');
  const [muted, setMuted] = useState(true);
  const [rewardGranted, setRewardGranted] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setCanClose(true);
          if (type === 'rewarded') {
            setRewardGranted(true);
            try {
              confetti({
                particleCount: 80,
                spread: 70,
                origin: { y: 0.6 },
              });
            } catch {
              // ignore
            }
          }
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [type]);

  const handleClose = () => {
    onClose(rewardGranted);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-md overflow-hidden rounded-2xl border border-slate-700 bg-slate-900 shadow-2xl flex flex-col">
        {/* Top bar mimicking Google AdMob overlay */}
        <div className="flex items-center justify-between border-b border-slate-800 bg-slate-950 px-4 py-2.5">
          <div className="flex items-center gap-2">
            <span className="rounded bg-amber-500/20 px-1.5 py-0.5 text-[10px] font-bold text-amber-400 border border-amber-500/30">
              {isTestMode ? 'TEST REKLAMI' : 'ADMOB CANLI'}
            </span>
            <span className="text-xs text-slate-400">
              {type === 'rewarded' ? 'Ödüllü Video Reklam' : 'Geçiş Reklamı (Interstitial)'}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setMuted(!muted)}
              className="p-1 text-slate-400 hover:text-white transition-colors"
              title="Sesi Aç/Kapat"
            >
              {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
            </button>

            {canClose ? (
              <button
                onClick={handleClose}
                className="flex items-center gap-1 rounded bg-slate-800 px-2 py-1 text-xs font-semibold text-white hover:bg-slate-700 transition-colors"
              >
                <span>Kapat</span>
                <X className="h-3.5 w-3.5" />
              </button>
            ) : (
              <div className="flex items-center gap-1 rounded bg-slate-800/80 px-2.5 py-1 text-xs font-mono text-amber-400">
                <span>{secondsLeft}s</span>
              </div>
            )}
          </div>
        </div>

        {/* Video / Banner Content Area */}
        <div className="relative aspect-[9/14] max-h-[460px] w-full bg-gradient-to-b from-slate-900 via-slate-800 to-slate-950 flex flex-col items-center justify-center p-6 text-center overflow-hidden">
          {/* Background simulated ad graphic */}
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_40%,rgba(59,130,246,0.15),transparent_70%)]" />

          {/* AdMob ID Watermark */}
          <div className="absolute top-3 left-3 right-3 flex items-center justify-between text-[11px] font-mono text-slate-400 bg-slate-900/80 backdrop-blur px-2.5 py-1 rounded-md border border-slate-800">
            <span className="truncate">Birim ID: {adId}</span>
            <span className="shrink-0 text-amber-400 ml-2">Simülasyon</span>
          </div>

          {/* Center Graphic */}
          <div className="relative z-10 flex flex-col items-center max-w-xs">
            {type === 'rewarded' ? (
              <div className="relative mb-5 flex h-20 w-20 items-center justify-center rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-500 shadow-lg shadow-orange-500/20 text-white animate-pulse">
                <Award className="h-10 w-10" />
              </div>
            ) : (
              <div className="relative mb-5 flex h-20 w-20 items-center justify-center rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 shadow-lg shadow-blue-500/20 text-white">
                <Play className="h-10 w-10 ml-1" />
              </div>
            )}

            <h3 className="text-xl font-bold text-white mb-2">
              {type === 'rewarded'
                ? 'Lojistik Premium Akaryakıt Kulübü'
                : 'Türkiye Geneli Yük Borsası'}
            </h3>
            
            <p className="text-sm text-slate-300 mb-6">
              {type === 'rewarded'
                ? 'Tüm petrol istasyonlarında şoförlere özel %8 anında mazot indirimi ve ücretsiz sefer asistanı.'
                : 'Dönüş yükünüzü dakikalar içinde bulun, boş dönmeyin. Tır ve kamyon sahiplerine özel yük ilanı platformu.'}
            </p>

            {type === 'rewarded' && (
              <div className="w-full rounded-xl bg-slate-900/90 border border-amber-500/30 p-3 mb-4">
                {rewardGranted ? (
                  <div className="flex items-center justify-center gap-2 text-emerald-400 font-medium text-sm">
                    <CheckCircle2 className="h-5 w-5" />
                    <span>Tebrikler! +1 VIP Jeton Hesabınıza Eklendi</span>
                  </div>
                ) : (
                  <div className="flex items-center justify-center gap-2 text-amber-300 text-xs">
                    <Award className="h-4 w-4 animate-spin" />
                    <span>Ödülü almak için {secondsLeft} saniye izleyin</span>
                  </div>
                )}
              </div>
            )}

            <button
              onClick={() => {
                window.open('https://admob.google.com', '_blank');
              }}
              className="w-full rounded-xl bg-gradient-to-r from-blue-600 to-amber-600 px-5 py-3 text-sm font-bold text-white shadow-lg hover:brightness-110 active:scale-[0.98] transition-all"
            >
              Hemen İncele / Uygulamayı Yükle
            </button>
          </div>
        </div>

        {/* Bottom AdMob Info */}
        <div className="bg-slate-950 p-3 border-t border-slate-800 text-center">
          <p className="text-[11px] text-slate-400">
            {isTestMode
              ? 'Google AdMob Resmi Test Reklamı. Gerçek Android cihazda native SDK render edilir.'
              : 'Canlı AdMob Reklam Birimi. Yayına girmeden önce AdMob panelinde hesap onayını kontrol edin.'}
          </p>
        </div>
      </div>
    </div>
  );
};
