import React, { useState, useEffect } from 'react';
import {
  Smartphone,
  ShieldCheck,
  Zap,
  Play,
  Award,
  Clock,
  Copy,
  Check,
  Code2,
  RefreshCw,
  ExternalLink,
  Sliders,
  AlertTriangle,
} from 'lucide-react';
import { admobService, AD_IDS, INTERSTITIAL_COOLDOWN_MS } from '../services/admobService';
import { AdMode } from '../types/trip';

interface AdMobControlPanelProps {
  onClose?: () => void;
  onOpenAabGuide?: () => void;
}

export const AdMobControlPanel: React.FC<AdMobControlPanelProps> = ({ onClose, onOpenAabGuide }) => {
  const [state, setState] = useState(admobService.getState());
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [remainingCooldown, setRemainingCooldown] = useState<number>(0);

  useEffect(() => {
    const unsub = admobService.subscribe(() => {
      setState(admobService.getState());
    });

    const interval = setInterval(() => {
      const remaining = Math.max(
        0,
        INTERSTITIAL_COOLDOWN_MS - (Date.now() - admobService.getState().lastInterstitialAt)
      );
      setRemainingCooldown(remaining);
    }, 1000);

    return () => {
      unsub();
      clearInterval(interval);
    };
  }, []);

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleModeChange = (newMode: AdMode) => {
    admobService.setAdMode(newMode);
  };

  const formatRemainingTime = (ms: number) => {
    if (ms <= 0) return 'Hazır (Süre doldu)';
    const totalSec = Math.ceil(ms / 1000);
    const m = Math.floor(totalSec / 60);
    const s = totalSec % 60;
    return `${m} dk ${s < 10 ? '0' : ''}${s} sn`;
  };

  const currentIds = AD_IDS[state.mode];

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="rounded-2xl border border-slate-700 bg-gradient-to-br from-slate-900 via-slate-850 to-slate-900 p-5 shadow-xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400">
              <Smartphone className="h-6 w-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold text-white">AdMob & Capacitor Kontrol Merkezi</h3>
                <span
                  className={`rounded-full px-2.5 py-0.5 text-[11px] font-semibold border ${
                    state.isNative
                      ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                      : 'bg-blue-500/10 text-blue-400 border-blue-500/30'
                  }`}
                >
                  {state.isNative ? 'Android Native SDK' : 'Web & Tarayıcı Simülatörü'}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Google AdMob banner, geçiş (interstitial) ve ödüllü (rewarded) reklam yönetimi.
              </p>
            </div>
          </div>

          {/* Mode Switcher */}
          <div className="flex items-center rounded-xl bg-slate-950 p-1 border border-slate-800 self-stretch sm:self-auto">
            <button
              onClick={() => handleModeChange('test')}
              className={`flex-1 sm:flex-none px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${
                state.mode === 'test'
                  ? 'bg-amber-500 text-slate-950 shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Test Modu (Google)
            </button>
            <button
              onClick={() => handleModeChange('production')}
              className={`flex-1 sm:flex-none px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${
                state.mode === 'production'
                  ? 'bg-emerald-500 text-slate-950 shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Canlı (Production)
            </button>
          </div>
        </div>

        {/* Live Status Container with exact id="adStatus" */}
        <div className="mt-4 rounded-xl bg-slate-950/80 border border-slate-800 p-3 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-start sm:items-center gap-2.5 w-full overflow-hidden">
            <div className="flex h-2.5 w-2.5 rounded-full bg-emerald-400 shrink-0 mt-1 sm:mt-0 animate-pulse" />
            <div className="text-xs text-slate-300 font-medium">
              <span className="text-slate-500 mr-1.5">Durum:</span>
              <span id="adStatus" className="text-slate-200">
                {state.statusMessage ||
                  (state.mode === 'test'
                    ? 'Test reklamları etkin. Yayına çıkmadan önce reklam testi ve rıza ayarlarını tamamla.'
                    : 'AdMob reklamları hazır.')}
              </span>
            </div>
          </div>

          <button
            onClick={() => void admobService.initializeAds()}
            className="shrink-0 flex items-center gap-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 px-3 py-1.5 text-xs font-medium text-slate-200 transition-colors"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            <span>Yeniden Başlat</span>
          </button>
        </div>
      </div>

      {/* Action Buttons Section with EXACT requested IDs */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Interstitial Ad Card */}
        <div className="rounded-xl border border-slate-850 bg-slate-900/70 p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Play className="h-5 w-5 text-blue-400" />
                <h4 className="text-sm font-bold text-white">Geçiş Reklamı (Interstitial)</h4>
              </div>
              <span className="text-[11px] font-mono text-slate-400">5 Dk Sıklık Sınırı</span>
            </div>

            <p className="text-xs text-slate-400 mb-3 leading-relaxed">
              Kullanıcı yeni sefer kaydettiğinde (<code>yuk-sefer-saved</code> olayı tetiklendiğinde)
              veya aşağıdaki butonla doğrudan açılır.
            </p>

            <div className="mb-4 flex items-center gap-2 rounded-lg bg-slate-950 px-3 py-2 text-xs border border-slate-800">
              <Clock className="h-4 w-4 text-amber-400 shrink-0" />
              <div className="flex-1">
                <span className="text-slate-400">Sonraki Reklam Süresi: </span>
                <span className="font-mono font-bold text-amber-300">
                  {state.bypassFrequencyCap ? 'Muaf (Süresiz Test)' : formatRemainingTime(remainingCooldown)}
                </span>
              </div>
            </div>

            <label className="flex items-center gap-2 text-xs text-slate-300 mb-4 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={state.bypassFrequencyCap}
                onChange={(e) => admobService.setBypassFrequencyCap(e.target.checked)}
                className="h-4 w-4 rounded border-slate-700 bg-slate-800 text-amber-500 focus:ring-amber-500/20"
              />
              <span>5 dakikalık bekleme süresini test için kaldır (Bypass Sıklık Sınırı)</span>
            </label>
          </div>

          {/* EXACT Button ID requested by user */}
          <button
            id="interstitialAdBtn"
            onClick={() => void admobService.showInterstitialAd(state.bypassFrequencyCap)}
            className="w-full flex items-center justify-center gap-2 rounded-xl bg-blue-600 hover:bg-blue-500 active:scale-[0.98] text-white font-bold py-2.5 text-xs shadow-md transition-all"
          >
            <Play className="h-4 w-4" />
            <span>Geçiş Reklamını Göster (showInterstitialAd)</span>
          </button>
        </div>

        {/* Rewarded Ad Card */}
        <div className="rounded-xl border border-slate-850 bg-slate-900/70 p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Award className="h-5 w-5 text-amber-400" />
                <h4 className="text-sm font-bold text-white">Ödüllü Video Reklam (Rewarded)</h4>
              </div>
              <span className="flex items-center gap-1 rounded bg-amber-500/10 px-2 py-0.5 text-[11px] font-bold text-amber-400 border border-amber-500/20">
                <span>{state.rewardTokens} VIP Jeton</span>
              </span>
            </div>

            <p className="text-xs text-slate-400 mb-3 leading-relaxed">
              Kullanıcı videoyu izleyip tamamladığında AdMob ödül callback tetiklenir ve uygulama içi
              VIP Mazot / Rapor analizi hakkı kazanılır.
            </p>

            <div className="mb-4 rounded-lg bg-slate-950 p-2.5 text-xs text-slate-300 border border-slate-800 flex items-center justify-between">
              <span className="text-slate-400">Mevcut Ödül Bakiye:</span>
              <span className="font-bold text-amber-400 font-mono text-sm">
                {state.rewardTokens} Adet
              </span>
            </div>
          </div>

          {/* EXACT Button ID requested by user */}
          <button
            id="rewardAdBtn"
            onClick={() => void admobService.showRewardedAd()}
            className="w-full flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 active:scale-[0.98] text-slate-950 font-bold py-2.5 text-xs shadow-md transition-all"
          >
            <Award className="h-4 w-4" />
            <span>Ödüllü Reklamı Göster (showRewardedAd)</span>
          </button>
        </div>
      </div>

      {/* Ad Unit IDs Reference Table */}
      <div className="rounded-2xl border border-slate-800 bg-slate-950/70 p-4">
        <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-2">
          <Code2 className="h-4 w-4 text-slate-400" />
          <span>Mevcut AdMob Birim Kimlikleri ({state.mode.toUpperCase()})</span>
        </h4>

        <div className="space-y-2">
          {(['banner', 'interstitial', 'rewarded'] as const).map((adType) => {
            const adId = currentIds[adType];
            const isCopied = copiedKey === adType;
            return (
              <div
                key={adType}
                className="flex items-center justify-between rounded-xl bg-slate-900 border border-slate-800/80 px-3 py-2 text-xs"
              >
                <div className="flex items-center gap-2 truncate">
                  <span className="rounded bg-slate-800 px-2 py-0.5 text-[10px] font-bold uppercase text-slate-300">
                    {adType}
                  </span>
                  <code className="text-[11px] font-mono text-slate-300 truncate">{adId}</code>
                </div>

                <button
                  onClick={() => copyToClipboard(adId, adType)}
                  className="shrink-0 ml-2 p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
                  title="Kopyala"
                >
                  {isCopied ? <Check className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4" />}
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Android Capacitor Setup Instructions Box */}
      <div className="rounded-2xl border border-blue-900/30 bg-blue-950/20 p-4">
        <div className="flex items-start gap-3">
          <AlertTriangle className="h-5 w-5 text-amber-400 shrink-0 mt-0.5" />
          <div className="text-xs text-slate-300 space-y-2">
            <h5 className="font-bold text-white text-sm">
              Android Studio / Capacitor İle Derlerken Unutulmaması Gerekenler:
            </h5>
            <p className="text-slate-400 leading-relaxed">
              AdMob Android uygulamasında çökmemesi için <code>android/app/src/main/AndroidManifest.xml</code> dosyasındaki <code>&lt;application&gt;</code> etiketinin içine App ID eklenmelidir:
            </p>
            <div className="relative rounded-lg bg-slate-950 border border-slate-800 p-2.5 font-mono text-[11px] text-amber-300 overflow-x-auto">
              <code>{`<meta-data
    android:name="com.google.android.gms.ads.APPLICATION_ID"
    android:value="${state.mode === 'test' ? 'ca-app-pub-3940256099942544~3347511713' : 'ca-app-pub-3759490841134440~UYGULAMA_ID_BURAYA'}" />`}</code>
            </div>
            <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 border-t border-slate-800/80">
              <span className="text-[11px] text-slate-400">
                Terminal komutları: <code>npx cap sync android</code> ve ardından <code>npx cap open android</code>
              </span>
              {onOpenAabGuide && (
                <button
                  type="button"
                  onClick={onOpenAabGuide}
                  className="flex items-center justify-center gap-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-3.5 py-2 text-xs shadow-md transition-all active:scale-95 shrink-0"
                >
                  <ExternalLink className="h-3.5 w-3.5" />
                  <span>Google Play .AAB Çıkarma Rehberi</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
