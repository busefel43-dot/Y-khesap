import React, { useState } from 'react';
import {
  X,
  Play,
  Check,
  Copy,
  Terminal,
  FileCode2,
  FolderOpen,
  UploadCloud,
  KeyRound,
  ShieldAlert,
  Smartphone,
  ExternalLink,
  ChevronRight,
  Sparkles,
  Layers,
  ArrowRight,
  Download,
} from 'lucide-react';

interface AabExportGuideModalProps {
  onClose: () => void;
}

export const AabExportGuideModal: React.FC<AabExportGuideModalProps> = ({ onClose }) => {
  const [activeTab, setActiveTab] = useState<'phone' | 'pc'>('phone');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const copy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-3 sm:p-5 overflow-y-auto">
      <div className="relative w-full max-w-3xl max-h-[92vh] flex flex-col rounded-2xl border border-slate-700 bg-slate-900 shadow-2xl overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 bg-slate-950 px-5 py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-600 text-slate-950 shadow-lg font-black">
              <UploadCloud className="h-6 w-6 text-slate-950" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold text-white">
                Google Play .AAB Çıkarma Rehberi
              </h3>
              <p className="text-xs text-slate-400">
                Bilgisayarın olmasa bile sadece telefon ve GitHub ile .AAB dosyasını çıkarabilirsin!
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Tab Selector: Phone (Recommended) vs PC */}
        <div className="flex border-b border-slate-800 bg-slate-950/60 p-2 gap-2">
          <button
            onClick={() => setActiveTab('phone')}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs sm:text-sm font-bold transition-all ${
              activeTab === 'phone'
                ? 'bg-emerald-500 text-slate-950 shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <Smartphone className="h-4 w-4" />
            <span>📱 Sadece Telefonum Var (GitHub İle Bulutta Çıkar)</span>
          </button>

          <button
            onClick={() => setActiveTab('pc')}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs sm:text-sm font-bold transition-all ${
              activeTab === 'pc'
                ? 'bg-amber-500 text-slate-950 shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <Terminal className="h-4 w-4" />
            <span>💻 Bilgisayarım Var (Android Studio)</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6">
          {activeTab === 'phone' ? (
            /* PHONE & GITHUB ACTIONS MODE */
            <div className="space-y-6">
              {/* Highlight Box */}
              <div className="rounded-2xl border border-emerald-500/30 bg-emerald-500/10 p-4">
                <div className="flex items-start gap-3">
                  <Sparkles className="h-5 w-5 text-emerald-400 shrink-0 mt-0.5" />
                  <div className="text-xs text-slate-200 leading-relaxed space-y-1">
                    <span className="font-bold text-emerald-300 block text-sm">
                      Müjde: Bilgisayara İhtiyacın Yok! Projene Otomatik Bulut Derleyicisi Eklendi.
                    </span>
                    Projenin içerisine <code>.github/workflows/build-aab.yml</code> dosyasını ekledim. GitHub'ın ücretsiz sunucuları Android Studio'yu bulutta çalıştırıp sana hazır <b>.aab</b> dosyasını üretecektir.
                  </div>
                </div>
              </div>

              {/* Step by step mobile guide */}
              <div className="space-y-4">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Telefondan Yapacağın 4 Basit Adım:
                </h4>

                {/* Step 1 */}
                <div className="rounded-2xl border border-slate-800 bg-slate-950/70 p-4 space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="flex h-6 w-6 items-center justify-center rounded-full bg-emerald-500 text-slate-950 font-bold text-xs">
                      1
                    </span>
                    <h5 className="text-sm font-bold text-white">
                      GitHub Reponu Telefonunun Tarayıcısında Aç
                    </h5>
                  </div>
                  <p className="text-xs text-slate-300 pl-8 leading-relaxed">
                    Telefonundan <a href="https://github.com" target="_blank" rel="noreferrer" className="text-emerald-400 underline font-semibold">github.com</a> adresine gir ve bu projenin bulunduğu depoyu (repository) aç.
                  </p>
                </div>

                {/* Step 2 */}
                <div className="rounded-2xl border border-slate-800 bg-slate-950/70 p-4 space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="flex h-6 w-6 items-center justify-center rounded-full bg-emerald-500 text-slate-950 font-bold text-xs">
                      2
                    </span>
                    <h5 className="text-sm font-bold text-white">
                      Üst Menüdeki "Actions" Sekmesine Dokun
                    </h5>
                  </div>
                  <p className="text-xs text-slate-300 pl-8 leading-relaxed">
                    Reponun üst çubuğunda (Code, Issues, Pull requests vb. yanında) bulunan <b>"Actions"</b> (İş Akışları) sekmesine tıkla.
                  </p>
                  <div className="ml-8 rounded-xl bg-slate-900 border border-slate-800 p-2.5 text-xs text-slate-400 flex items-center gap-2">
                    <Play className="h-4 w-4 text-emerald-400" />
                    <span>Listede <b>"Build Android AAB and APK"</b> iş akışını göreceksin. Ona dokun.</span>
                  </div>
                </div>

                {/* Step 3 */}
                <div className="rounded-2xl border border-slate-800 bg-slate-950/70 p-4 space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="flex h-6 w-6 items-center justify-center rounded-full bg-emerald-500 text-slate-950 font-bold text-xs">
                      3
                    </span>
                    <h5 className="text-sm font-bold text-white">
                      "Run workflow" (İş Akışını Başlat) Butonuna Bas
                    </h5>
                  </div>
                  <p className="text-xs text-slate-300 pl-8 leading-relaxed">
                    Sağ taraftaki mavi veya gri <b>"Run workflow"</b> butonuna bas, ardından yeşil renkli <b>"Run workflow"</b> onayına tıkla.
                  </p>
                  <div className="ml-8 rounded-xl bg-slate-900 border border-slate-800 p-2.5 text-xs text-emerald-300">
                    ⏱️ GitHub bulut sunucuları otomatik başlar. Yaklaşık 2-3 dakika içinde derleme tamamlanıp yanında <b>yeşil onay işareti (✅)</b> çıkar.
                  </div>
                </div>

                {/* Step 4 */}
                <div className="rounded-2xl border border-slate-800 bg-slate-950/70 p-4 space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="flex h-6 w-6 items-center justify-center rounded-full bg-emerald-500 text-slate-950 font-bold text-xs">
                      4
                    </span>
                    <h5 className="text-sm font-bold text-white">
                      AAB Dosyasını Telefonuna İndir
                    </h5>
                  </div>
                  <p className="text-xs text-slate-300 pl-8 leading-relaxed">
                    Tamamlanan işleme (yeşil tikli olan) tıkla ve sayfanın en altına kaydır. <b>Artifacts</b> (Eserler) bölümünde iki adet indirme butonu göreceksin:
                  </p>
                  <div className="ml-8 space-y-2">
                    <div className="rounded-xl bg-slate-900 border border-emerald-500/30 p-3 flex items-center justify-between text-xs">
                      <div>
                        <span className="font-bold text-emerald-400 block">📦 google-play-app-release-aab</span>
                        <span className="text-[11px] text-slate-400">Google Play Console'a yükleyeceğin .AAB dosyası</span>
                      </div>
                      <span className="rounded bg-emerald-500/20 text-emerald-300 px-2 py-1 text-[11px] font-bold">
                        İndir (.zip)
                      </span>
                    </div>

                    <div className="rounded-xl bg-slate-900 border border-blue-500/30 p-3 flex items-center justify-between text-xs">
                      <div>
                        <span className="font-bold text-blue-400 block">📱 test-kurulum-app-debug-apk</span>
                        <span className="text-[11px] text-slate-400">Telefonuna doğrudan kurup AdMob'u test edeceğin APK</span>
                      </div>
                      <span className="rounded bg-blue-500/20 text-blue-300 px-2 py-1 text-[11px] font-bold">
                        İndir (.zip)
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Troubleshooting Note for Phone users */}
              <div className="rounded-xl border border-amber-500/30 bg-amber-500/5 p-4 text-xs text-slate-300 space-y-2">
                <span className="font-bold text-amber-400 block">⚠️ Telefonda Karşılaşabileceğin Durumlar:</span>
                <ul className="list-disc list-inside space-y-1 text-slate-400 pl-1">
                  <li>İndirdiğin dosya <code>.zip</code> olarak iner. Telefonunun "Dosyalarım" uygulamasından arşivi açıp içindeki <code>.aab</code> dosyasını çıkarabilirsin.</li>
                  <li>Google Play Console'a yüklerken doğrudan o <code>.aab</code> dosyasını seçmen yeterlidir.</li>
                  <li>Eğer depoyu private (gizli) yaptıysan, GitHub Actions ayarlarının açık olduğundan emin ol.</li>
                </ul>
              </div>
            </div>
          ) : (
            /* PC & ANDROID STUDIO MODE */
            <div className="space-y-5">
              <div className="rounded-2xl border border-slate-800 bg-slate-950/70 p-4 space-y-3">
                <div className="flex items-center gap-2.5">
                  <span className="flex h-6 w-6 items-center justify-center rounded-full bg-amber-500 text-slate-950 font-bold text-xs">
                    1
                  </span>
                  <h4 className="text-sm font-bold text-white">Terminal Komutları</h4>
                </div>
                <div className="relative rounded-xl bg-slate-900 border border-slate-800 p-3 font-mono text-xs text-amber-300 flex items-center justify-between">
                  <pre className="overflow-x-auto whitespace-pre">
                    <code>npm run build{'\n'}npx cap add android{'\n'}npx cap sync android{'\n'}npx cap open android</code>
                  </pre>
                  <button
                    onClick={() => copy('npm run build\nnpx cap add android\nnpx cap sync android\nnpx cap open android', 'pc-cmds')}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 self-start"
                  >
                    {copiedKey === 'pc-cmds' ? <Check className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4" />}
                  </button>
                </div>
              </div>

              <div className="rounded-2xl border border-slate-800 bg-slate-950/70 p-4 space-y-3">
                <div className="flex items-center gap-2.5">
                  <span className="flex h-6 w-6 items-center justify-center rounded-full bg-amber-500 text-slate-950 font-bold text-xs">
                    2
                  </span>
                  <h4 className="text-sm font-bold text-white">Android Studio Menüsü</h4>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Android Studio açılınca: <b>Build ➔ Generate Signed Bundle / APK ➔ Android App Bundle</b> seçip <b>Next</b> deyin ve <b>release</b> varyantını seçerek derleyin.
                </p>
                <div className="rounded-xl bg-slate-900 border border-slate-800 p-3 font-mono text-xs text-emerald-400">
                  Dosya Çıktısı: <code>android/app/release/app-release.aab</code>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-slate-800 bg-slate-950 px-5 py-3.5 flex items-center justify-between">
          <a
            href="https://github.com"
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-1.5 text-xs text-emerald-400 hover:text-emerald-300 font-semibold"
          >
            <span>GitHub'ı Aç</span>
            <ExternalLink className="h-3.5 w-3.5" />
          </a>

          <button
            onClick={onClose}
            className="rounded-xl bg-emerald-500 hover:bg-emerald-400 px-5 py-2 text-xs font-bold text-slate-950 transition-colors"
          >
            Anladım, Kapat
          </button>
        </div>
      </div>
    </div>
  );
};
