import React from 'react';
import { TrendingUp, DollarSign, Fuel, Map, Award, ShieldCheck, Clock } from 'lucide-react';
import { Trip } from '../types/trip';
import { calculateTotalExpense, calculateNetProfit, formatTL } from '../utils/storage';

interface DashboardStatsProps {
  trips: Trip[];
  rewardTokens: number;
  adMode: 'test' | 'production';
  onOpenAdMob: () => void;
}

export const DashboardStats: React.FC<DashboardStatsProps> = ({
  trips,
  rewardTokens,
  adMode,
  onOpenAdMob,
}) => {
  const totalRevenue = trips.reduce((acc, t) => acc + (t.freightRevenue || 0), 0);
  const totalExpense = trips.reduce((acc, t) => acc + calculateTotalExpense(t.expenses), 0);
  const totalProfit = totalRevenue - totalExpense;
  const overallMargin = totalRevenue > 0 ? ((totalProfit / totalRevenue) * 100).toFixed(1) : '0';
  const totalKm = trips.reduce((acc, t) => acc + (t.distanceKm || 0), 0);
  const activeTripsCount = trips.filter((t) => t.status === 'Yolda' || t.status === 'Ödeme Bekliyor').length;

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
      {/* 1. Toplam Navlun Geliri */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-4 shadow-lg flex flex-col justify-between">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-400">Toplam Navlun Ciro</span>
          <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <DollarSign className="h-4 w-4" />
          </div>
        </div>
        <div className="mt-3">
          <div className="text-lg sm:text-2xl font-black font-mono text-emerald-400 tracking-tight">
            {formatTL(totalRevenue)}
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            {trips.length} Sefer Toplamı
          </span>
        </div>
      </div>

      {/* 2. Toplam Sefer Giderleri */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-4 shadow-lg flex flex-col justify-between">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-400">Mazot & Sefer Gideri</span>
          <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-rose-500/10 text-rose-400 border border-rose-500/20">
            <Fuel className="h-4 w-4" />
          </div>
        </div>
        <div className="mt-3">
          <div className="text-lg sm:text-2xl font-black font-mono text-rose-400 tracking-tight">
            {formatTL(totalExpense)}
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            Mazot, HGS, Harcırah, Tamir
          </span>
        </div>
      </div>

      {/* 3. Net Kâr */}
      <div className="rounded-2xl border border-amber-500/30 bg-gradient-to-br from-slate-900 via-slate-900 to-amber-950/20 p-4 shadow-lg flex flex-col justify-between">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-amber-300">Net Kâr & Marj</span>
          <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <TrendingUp className="h-4 w-4" />
          </div>
        </div>
        <div className="mt-3">
          <div className="text-lg sm:text-2xl font-black font-mono text-amber-400 tracking-tight">
            {formatTL(totalProfit)}
          </div>
          <span className="text-[11px] text-emerald-400 font-semibold mt-1 block">
            %{overallMargin} Ortalama Kâr Marjı
          </span>
        </div>
      </div>

      {/* 4. Aktif Seferler & AdMob Durumu */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-4 shadow-lg flex flex-col justify-between">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-400">Filo & AdMob</span>
          <button
            onClick={onOpenAdMob}
            className="flex items-center gap-1 text-[11px] font-bold text-amber-400 hover:text-amber-300 underline"
          >
            AdMob Ayar
          </button>
        </div>
        <div className="mt-3 flex items-center justify-between">
          <div>
            <div className="text-lg sm:text-2xl font-black font-mono text-white">
              {activeTripsCount} <span className="text-xs font-normal text-slate-400">Yolda</span>
            </div>
            <span className="text-[11px] text-slate-400 block mt-1">
              {totalKm.toLocaleString('tr-TR')} Km Yol
            </span>
          </div>

          <div className="text-right">
            <span
              className={`inline-block rounded-md px-2 py-0.5 text-[10px] font-bold border ${
                adMode === 'production'
                  ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                  : 'bg-amber-500/10 text-amber-400 border-amber-500/30'
              }`}
            >
              {adMode.toUpperCase()}
            </span>
            <div className="flex items-center justify-end gap-1 text-[11px] font-mono text-amber-400 mt-1 font-bold">
              <Award className="h-3 w-3" />
              <span>{rewardTokens} Jeton</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
