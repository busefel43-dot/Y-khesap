import React, { useState } from 'react';
import { X, Truck, DollarSign, Fuel, MapPin, Calendar, FileText, Check, AlertCircle } from 'lucide-react';
import { Trip, TripStatus } from '../types/trip';
import { formatTL } from '../utils/storage';

interface TripFormModalProps {
  initialTrip?: Trip | null;
  onSave: (trip: Trip) => void;
  onClose: () => void;
}

const CARGO_SUGGESTIONS = [
  'Paletli Kuru Gıda',
  'Rulo Sac & Profil',
  'İnşaat Malzemesi & Çimento',
  'Demir & Çelik Çubuk',
  'Soğuk Zincir / Frigo Gıda',
  'Konteyner (20/40 DC)',
  'Otomotiv Yedek Parça',
  'Kimyasal Hammadde',
  'Meyve & Sebze',
  'Mobilya & Beyaz Eşya',
  'Tekstil & Konfeksiyon',
];

const COMMON_CITIES = [
  'İstanbul',
  'Ankara',
  'İzmir',
  'Bursa',
  'Kocaeli',
  'Mersin',
  'Adana',
  'Gaziantep',
  'Kayseri',
  'Konya',
  'Antalya',
  'Samsun',
  'Trabzon',
  'Tekirdağ',
  'Denizli',
  'Eskişehir',
];

export const TripFormModal: React.FC<TripFormModalProps> = ({
  initialTrip,
  onSave,
  onClose,
}) => {
  const [plate, setPlate] = useState(initialTrip?.plate || '34 ');
  const [driverName, setDriverName] = useState(initialTrip?.driverName || '');
  const [departureCity, setDepartureCity] = useState(initialTrip?.departureCity || 'İstanbul');
  const [destinationCity, setDestinationCity] = useState(initialTrip?.destinationCity || 'Ankara');
  const [cargoType, setCargoType] = useState(initialTrip?.cargoType || 'Paletli Kuru Gıda');
  const [weightTons, setWeightTons] = useState<number>(initialTrip?.weightTons || 22);
  const [distanceKm, setDistanceKm] = useState<number>(initialTrip?.distanceKm || 450);
  const [freightRevenue, setFreightRevenue] = useState<number>(initialTrip?.freightRevenue || 28000);

  // Expenses
  const [fuelCost, setFuelCost] = useState<number>(initialTrip?.expenses.fuelCost || 6800);
  const [fuelLiters, setFuelLiters] = useState<number | undefined>(initialTrip?.expenses.fuelLiters || 150);
  const [tollCost, setTollCost] = useState<number>(initialTrip?.expenses.tollCost || 1200);
  const [foodAllowanceCost, setFoodAllowanceCost] = useState<number>(initialTrip?.expenses.foodAllowanceCost || 750);
  const [maintenanceCost, setMaintenanceCost] = useState<number>(initialTrip?.expenses.maintenanceCost || 0);
  const [otherCosts, setOtherCosts] = useState<number>(initialTrip?.expenses.otherCosts || 300);

  const [invoiceNumber, setInvoiceNumber] = useState(initialTrip?.invoiceNumber || '');
  const [notes, setNotes] = useState(initialTrip?.notes || '');
  const [status, setStatus] = useState<TripStatus>(initialTrip?.status || 'Yolda');
  const [date, setDate] = useState(initialTrip?.date || new Date().toISOString().split('T')[0]);

  // Live Calculations
  const totalExpense = fuelCost + tollCost + foodAllowanceCost + maintenanceCost + otherCosts;
  const netProfit = freightRevenue - totalExpense;
  const profitMargin = freightRevenue > 0 ? ((netProfit / freightRevenue) * 100).toFixed(1) : '0';
  const revenuePerKm = distanceKm > 0 ? (freightRevenue / distanceKm).toFixed(1) : '0';
  const profitPerKm = distanceKm > 0 ? (netProfit / distanceKm).toFixed(1) : '0';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!plate.trim() || !departureCity.trim() || !destinationCity.trim()) {
      alert('Lütfen plaka, çıkış ve varış yerini doldurunuz.');
      return;
    }

    const tripData: Trip = {
      id: initialTrip?.id || `tr-${Date.now().toString(36)}`,
      plate: plate.toUpperCase().trim(),
      driverName: driverName.trim() || undefined,
      departureCity: departureCity.trim(),
      destinationCity: destinationCity.trim(),
      cargoType: cargoType.trim(),
      weightTons: Number(weightTons) || 0,
      distanceKm: Number(distanceKm) || 0,
      freightRevenue: Number(freightRevenue) || 0,
      expenses: {
        fuelCost: Number(fuelCost) || 0,
        fuelLiters: fuelLiters ? Number(fuelLiters) : undefined,
        tollCost: Number(tollCost) || 0,
        foodAllowanceCost: Number(foodAllowanceCost) || 0,
        maintenanceCost: Number(maintenanceCost) || 0,
        otherCosts: Number(otherCosts) || 0,
      },
      invoiceNumber: invoiceNumber.trim() || undefined,
      notes: notes.trim() || undefined,
      status,
      date,
      createdAt: initialTrip?.createdAt || Date.now(),
    };

    onSave(tripData);

    // CRITICAL REQUIREMENT: Trigger the AdMob Interstitial event requested by user!
    // "window.addEventListener('yuk-sefer-saved', () => { void showInterstitialAd(); });"
    try {
      window.dispatchEvent(new CustomEvent('yuk-sefer-saved', { detail: { tripId: tripData.id } }));
    } catch (err) {
      console.warn('yuk-sefer-saved olayı fırlatılırken hata:', err);
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-3 sm:p-4 overflow-y-auto">
      <div className="relative w-full max-w-2xl max-h-[92vh] flex flex-col rounded-2xl border border-slate-700 bg-slate-900 shadow-2xl overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 bg-slate-950 px-5 py-3.5">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400">
              <Truck className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">
                {initialTrip ? 'Sefer Bilgilerini Düzenle' : 'Yeni Sefer & Navlun Kaydı'}
              </h3>
              <p className="text-xs text-slate-400">
                Kayıt sonrası AdMob geçiş reklamı (interstitial) tetiklenir.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-5 space-y-5">
          {/* Araç ve Şoför Bilgileri */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-2">
              <Truck className="h-4 w-4 text-amber-400" />
              <span>1. Araç & Şoför</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Araç Plakası *</label>
                <input
                  type="text"
                  required
                  value={plate}
                  onChange={(e) => setPlate(e.target.value)}
                  placeholder="34 LOR 88"
                  className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white font-mono uppercase focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Şoför / Kaptan</label>
                <input
                  type="text"
                  value={driverName}
                  onChange={(e) => setDriverName(e.target.value)}
                  placeholder="Ahmet Usta"
                  className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Tarih</label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white focus:border-amber-500 focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Rota ve Yük Bilgisi */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-2">
              <MapPin className="h-4 w-4 text-blue-400" />
              <span>2. Güzergâh & Yük</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Çıkış Noktası *</label>
                <input
                  type="text"
                  list="city-list"
                  required
                  value={departureCity}
                  onChange={(e) => setDepartureCity(e.target.value)}
                  placeholder="İstanbul (Tuzla)"
                  className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Varış Noktası *</label>
                <input
                  type="text"
                  list="city-list"
                  required
                  value={destinationCity}
                  onChange={(e) => setDestinationCity(e.target.value)}
                  placeholder="Ankara (Ostim)"
                  className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Mesafe (Km)</label>
                <input
                  type="number"
                  min="0"
                  value={distanceKm}
                  onChange={(e) => setDistanceKm(Number(e.target.value))}
                  placeholder="450"
                  className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white focus:border-amber-500 focus:outline-none"
                />
              </div>
            </div>

            <datalist id="city-list">
              {COMMON_CITIES.map((c) => (
                <option key={c} value={c} />
              ))}
            </datalist>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Yük Cinsi</label>
                <input
                  type="text"
                  list="cargo-list"
                  value={cargoType}
                  onChange={(e) => setCargoType(e.target.value)}
                  placeholder="Paletli Kuru Gıda"
                  className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white focus:border-amber-500 focus:outline-none"
                />
                <datalist id="cargo-list">
                  {CARGO_SUGGESTIONS.map((cg) => (
                    <option key={cg} value={cg} />
                  ))}
                </datalist>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Tonaj (Ton)</label>
                <input
                  type="number"
                  step="0.1"
                  min="0"
                  value={weightTons}
                  onChange={(e) => setWeightTons(Number(e.target.value))}
                  placeholder="22.5"
                  className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white focus:border-amber-500 focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Navlun Geliri ve Giderler */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-2">
              <DollarSign className="h-4 w-4 text-emerald-400" />
              <span>3. Navlun Geliri & Sefer Giderleri</span>
            </h4>

            <div className="rounded-xl border border-emerald-500/20 bg-emerald-500/5 p-3.5">
              <label className="block text-xs font-bold text-emerald-400 mb-1">
                Anlaşılan Navlun Tutarı (TL) *
              </label>
              <div className="relative">
                <input
                  type="number"
                  min="0"
                  required
                  value={freightRevenue}
                  onChange={(e) => setFreightRevenue(Number(e.target.value))}
                  placeholder="30000"
                  className="w-full rounded-xl border border-emerald-500/40 bg-slate-950 px-3 py-2.5 text-base font-bold text-emerald-300 focus:border-emerald-500 focus:outline-none"
                />
                <span className="absolute right-3 top-2.5 font-bold text-emerald-500">₺</span>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Mazot Gideri (₺)</label>
                <input
                  type="number"
                  min="0"
                  value={fuelCost}
                  onChange={(e) => setFuelCost(Number(e.target.value))}
                  placeholder="7000"
                  className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Yakıt Miktarı (Litre)</label>
                <input
                  type="number"
                  min="0"
                  value={fuelLiters || ''}
                  onChange={(e) => setFuelLiters(e.target.value ? Number(e.target.value) : undefined)}
                  placeholder="160"
                  className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Köprü & Otoyol (HGS)</label>
                <input
                  type="number"
                  min="0"
                  value={tollCost}
                  onChange={(e) => setTollCost(Number(e.target.value))}
                  placeholder="1500"
                  className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Harcırah / Yemek</label>
                <input
                  type="number"
                  min="0"
                  value={foodAllowanceCost}
                  onChange={(e) => setFoodAllowanceCost(Number(e.target.value))}
                  placeholder="800"
                  className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Lastik & Bakım</label>
                <input
                  type="number"
                  min="0"
                  value={maintenanceCost}
                  onChange={(e) => setMaintenanceCost(Number(e.target.value))}
                  placeholder="0"
                  className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Diğer / Hamaliye</label>
                <input
                  type="number"
                  min="0"
                  value={otherCosts}
                  onChange={(e) => setOtherCosts(Number(e.target.value))}
                  placeholder="400"
                  className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white focus:border-amber-500 focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* İrsaliye, Not ve Durum */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">İrsaliye / Fatura No</label>
              <input
                type="text"
                value={invoiceNumber}
                onChange={(e) => setInvoiceNumber(e.target.value)}
                placeholder="IRS-2026-0098"
                className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white focus:border-amber-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Sefer Durumu</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as TripStatus)}
                className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white focus:border-amber-500 focus:outline-none"
              >
                <option value="Yolda">Yolda (Taşınıyor)</option>
                <option value="Teslim Edildi">Teslim Edildi</option>
                <option value="Faturalandı">Faturalandı</option>
                <option value="Ödeme Bekliyor">Ödeme Bekliyor</option>
                <option value="Tamamlandı">Tamamlandı</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Özel Notlar</label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Yükleme saatleri, rampa bilgisi veya köprü geçiş detayları..."
              className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white focus:border-amber-500 focus:outline-none"
            />
          </div>

          {/* Canlı Kâr Özeti Kartı */}
          <div className="rounded-2xl border border-slate-700 bg-slate-950 p-4 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400">Toplam Sefer Gideri:</span>
              <span className="font-semibold text-rose-400 font-mono">{formatTL(totalExpense)}</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400">KM Başına Gelir:</span>
              <span className="font-semibold text-slate-200 font-mono">{revenuePerKm} ₺/km</span>
            </div>
            <div className="flex items-center justify-between border-t border-slate-800 pt-2">
              <div>
                <span className="text-xs text-slate-300 font-bold">Hesaplanan Net Kâr:</span>
                <span className="ml-2 text-[11px] text-emerald-400 font-bold">(%{profitMargin} Kâr Marjı)</span>
              </div>
              <span
                className={`text-lg font-extrabold font-mono ${
                  netProfit >= 0 ? 'text-emerald-400' : 'text-rose-500'
                }`}
              >
                {formatTL(netProfit)}
              </span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl px-4 py-2.5 text-xs font-semibold text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              Vazgeç
            </button>
            <button
              type="submit"
              className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 active:scale-95 px-6 py-2.5 text-sm font-bold text-slate-950 shadow-lg transition-all"
            >
              <Check className="h-4 w-4" />
              <span>Seferi Kaydet & Reklamı Tetikle</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
