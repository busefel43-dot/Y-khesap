import { Capacitor } from '@capacitor/core';
import {
  AdMob,
  AdmobConsentStatus,
  BannerAdSize,
  BannerAdPosition,
} from '@capacitor-community/admob';
import { AdMode, AdMobIds } from '../types/trip';

export const AD_IDS: Record<AdMode, AdMobIds> = {
  test: {
    banner: 'ca-app-pub-3940256099942544/6300978111',
    interstitial: 'ca-app-pub-3940256099942544/1033173712',
    rewarded: 'ca-app-pub-3940256099942544/5224354917',
  },
  production: {
    banner: 'ca-app-pub-3759490841134440/4471761226',
    interstitial: 'ca-app-pub-3759490841134440/3534084077',
    rewarded: 'ca-app-pub-3759490841134440/9456047488',
  },
};

export const INTERSTITIAL_COOLDOWN_MS = 5 * 60 * 1000; // 5 dakika

class AdMobManager {
  private adMode: AdMode = 'test';
  private initialized = false;
  private interstitialReady = false;
  private rewardedReady = false;
  private lastInterstitialAt = 0;
  private isNative = Capacitor.isNativePlatform();
  private listeners: Array<() => void> = [];
  private bypassFrequencyCap = false;

  // Simulator state for Web testing
  private simulatedModal: 'none' | 'interstitial' | 'rewarded' = 'none';
  private statusMessage = '';
  private rewardTokens = 0;

  constructor() {
    // LocalStorage'dan mod tercihini yükle
    const savedMode = localStorage.getItem('app_ad_mode') as AdMode | null;
    if (savedMode === 'production' || savedMode === 'test') {
      this.adMode = savedMode;
    }

    const savedTokens = localStorage.getItem('app_reward_tokens');
    if (savedTokens) {
      this.rewardTokens = parseInt(savedTokens, 10) || 0;
    }

    const savedLastInter = localStorage.getItem('app_last_interstitial');
    if (savedLastInter) {
      this.lastInterstitialAt = parseInt(savedLastInter, 10) || 0;
    }
  }

  public subscribe(listener: () => void) {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  private notify() {
    this.listeners.forEach((l) => l());
  }

  public getAdMode(): AdMode {
    return this.adMode;
  }

  public setAdMode(mode: AdMode) {
    this.adMode = mode;
    localStorage.setItem('app_ad_mode', mode);
    this.status(`Reklam modu '${mode === 'production' ? 'CANLI (Production)' : 'TEST (Google Test IDs)'}' olarak ayarlandı.`);
    // Yeniden başlatmayı tetikle
    if (this.isNative) {
      void this.initializeAds();
    } else {
      this.notify();
    }
  }

  public setBypassFrequencyCap(bypass: boolean) {
    this.bypassFrequencyCap = bypass;
    this.notify();
  }

  public getBypassFrequencyCap(): boolean {
    return this.bypassFrequencyCap;
  }

  public getAdIds(): AdMobIds {
    return AD_IDS[this.adMode];
  }

  public getState() {
    return {
      mode: this.adMode,
      isNative: this.isNative,
      initialized: this.initialized,
      interstitialReady: this.interstitialReady,
      rewardedReady: this.rewardedReady,
      lastInterstitialAt: this.lastInterstitialAt,
      statusMessage: this.statusMessage,
      rewardTokens: this.rewardTokens,
      bypassFrequencyCap: this.bypassFrequencyCap,
      simulatedModal: this.simulatedModal,
      cooldownRemainingMs: Math.max(0, INTERSTITIAL_COOLDOWN_MS - (Date.now() - this.lastInterstitialAt)),
    };
  }

  public status(message: string) {
    this.statusMessage = message;
    const node = document.getElementById('adStatus');
    if (node) {
      node.textContent = message;
    }
    this.notify();
  }

  public async prepareInterstitial(): Promise<boolean> {
    if (!this.isNative) {
      this.interstitialReady = true;
      this.notify();
      return true;
    }
    try {
      const adIds = this.getAdIds();
      await AdMob.prepareInterstitial({ adId: adIds.interstitial });
      this.interstitialReady = true;
      this.notify();
      return true;
    } catch (error) {
      this.interstitialReady = false;
      console.warn('Interstitial yüklenemedi:', error);
      this.notify();
      return false;
    }
  }

  public async prepareRewarded(): Promise<boolean> {
    if (!this.isNative) {
      this.rewardedReady = true;
      this.notify();
      return true;
    }
    try {
      const adIds = this.getAdIds();
      await AdMob.prepareRewardVideoAd({ adId: adIds.rewarded });
      this.rewardedReady = true;
      this.notify();
      return true;
    } catch (error) {
      this.rewardedReady = false;
      console.warn('Ödüllü reklam yüklenemedi:', error);
      this.notify();
      return false;
    }
  }

  public async initializeAds(): Promise<void> {
    if (!this.isNative) {
      this.initialized = true;
      this.interstitialReady = true;
      this.rewardedReady = true;
      this.status('Tarayıcı modu aktif: Reklamlar Android uygulamasında AdMob üzerinden çalışır; web önizlemesinde interaktif simülatör devrededir.');
      this.notify();
      return;
    }

    try {
      let consent = await AdMob.requestConsentInfo();
      if (consent.isConsentFormAvailable && consent.status === AdmobConsentStatus.REQUIRED) {
        consent = await AdMob.showConsentForm();
      }
      if (!consent.canRequestAds) {
        this.status('Reklam göstermek için gerekli kullanıcı izni henüz mevcut değil.');
        return;
      }

      await AdMob.initialize();
      this.initialized = true;

      const adIds = this.getAdIds();
      await AdMob.showBanner({
        adId: adIds.banner,
        adSize: BannerAdSize.ADAPTIVE_BANNER,
        position: BannerAdPosition.BOTTOM_CENTER,
        margin: 0,
      });

      await Promise.all([this.prepareInterstitial(), this.prepareRewarded()]);
      this.status(
        this.adMode === 'test'
          ? 'Test reklamları etkin. Yayına çıkmadan önce reklam testi ve rıza ayarlarını tamamla.'
          : 'AdMob reklamları hazır.'
      );
    } catch (error) {
      console.error('AdMob başlatılamadı:', error);
      this.status('Reklamlar şu anda yüklenemedi. Uygulamanın diğer özellikleri çalışmaya devam eder.');
    } finally {
      this.notify();
    }
  }

  public async showInterstitialAd(forceBypass = false): Promise<boolean> {
    const now = Date.now();
    const timeDiff = now - this.lastInterstitialAt;

    if (!forceBypass && !this.bypassFrequencyCap && timeDiff < INTERSTITIAL_COOLDOWN_MS) {
      const remainingSeconds = Math.ceil((INTERSTITIAL_COOLDOWN_MS - timeDiff) / 1000);
      const minutes = Math.floor(remainingSeconds / 60);
      const seconds = remainingSeconds % 60;
      this.status(`Geçiş reklamı sıklık sınırında. Kalan süre: ${minutes}d ${seconds}s.`);
      return false;
    }

    // If on native platform:
    if (this.isNative) {
      if (!this.initialized) {
        this.status('AdMob henüz başlatılmadı.');
        return false;
      }
      try {
        if (!this.interstitialReady) {
          await this.prepareInterstitial();
        }
        if (!this.interstitialReady) {
          this.status('Geçiş reklamı hazır değil.');
          return false;
        }

        await AdMob.showInterstitial();
        this.lastInterstitialAt = Date.now();
        localStorage.setItem('app_last_interstitial', this.lastInterstitialAt.toString());
        this.interstitialReady = false;
        this.status('Geçiş reklamı gösterildi.');
        void this.prepareInterstitial();
        return true;
      } catch (error) {
        console.warn('Geçiş reklamı gösterilemedi:', error);
        this.interstitialReady = false;
        void this.prepareInterstitial();
        return false;
      }
    }

    // Web simulation:
    this.simulatedModal = 'interstitial';
    this.lastInterstitialAt = Date.now();
    localStorage.setItem('app_last_interstitial', this.lastInterstitialAt.toString());
    this.status('Simülatör: Geçiş reklamı gösteriliyor (Test ID: ca-app-pub-3940256099942544/1033173712).');
    this.notify();
    return true;
  }

  public async showRewardedAd(): Promise<void> {
    if (!this.isNative) {
      // Show simulated rewarded ad
      this.simulatedModal = 'rewarded';
      this.status('Simülatör: Ödüllü video reklam başladı.');
      this.notify();
      return;
    }

    if (!this.initialized) {
      this.status('Ödüllü reklam Android uygulamasında kullanılabilir.');
      return;
    }

    try {
      if (!this.rewardedReady) {
        await this.prepareRewarded();
      }
      if (!this.rewardedReady) {
        this.status('Ödüllü video henüz hazır değil. Biraz sonra tekrar dene.');
        return;
      }

      const reward = await AdMob.showRewardVideoAd();
      this.rewardedReady = false;
      const amount = reward?.amount || 1;
      this.addRewardTokens(amount);
      this.status(`Video tamamlandı. Reklam ödül olayı alındı (${amount} Adet Ödül Jetonu).`);
      void this.prepareRewarded();
    } catch (error) {
      console.warn('Ödüllü reklam gösterilemedi veya tamamlanmadı:', error);
      this.rewardedReady = false;
      this.status('Video tamamlanmadı veya reklam yüklenemedi. Tekrar deneyebilirsin.');
      void this.prepareRewarded();
    } finally {
      this.notify();
    }
  }

  public closeSimulatedModal(rewardGranted = false) {
    if (this.simulatedModal === 'rewarded' && rewardGranted) {
      this.addRewardTokens(1);
      this.status('Video tamamlandı. Simüle edilmiş AdMob ödülü alındı (+1 VIP Jeton).');
    }
    this.simulatedModal = 'none';
    this.notify();
  }

  public addRewardTokens(count: number) {
    this.rewardTokens += count;
    localStorage.setItem('app_reward_tokens', this.rewardTokens.toString());
    this.notify();
  }

  public spendRewardToken(count: number): boolean {
    if (this.rewardTokens >= count) {
      this.rewardTokens -= count;
      localStorage.setItem('app_reward_tokens', this.rewardTokens.toString());
      this.notify();
      return true;
    }
    return false;
  }
}

export const admobService = new AdMobManager();

// Global Window Event Listener for 'yuk-sefer-saved'
if (typeof window !== 'undefined') {
  window.addEventListener('yuk-sefer-saved', () => {
    console.log('[AdMob] "yuk-sefer-saved" olayı yakalandı. Geçiş reklamı tetikleniyor...');
    void admobService.showInterstitialAd();
  });
}
