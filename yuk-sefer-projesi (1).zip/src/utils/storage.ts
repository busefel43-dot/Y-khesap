import { Trip } from '../types/trip';

const TRIPS_KEY = 'yuk_sefer_defteri_trips_v1';

export const INITIAL_TRIPS: Trip[] = [
  {
    id: 'tr-101',
    plate: '34 LOR 882',
    driverName: 'Ahmet Usta',
    departureCity: 'İstanbul (Tuzla OSB)',
    destinationCity: 'Ankara (Ostim)',
    cargoType: 'Paletli Otomotiv Yedek Parça',
    weightTons: 22.5,
    distanceKm: 460,
    freightRevenue: 28500,
    expenses: {
      fuelCost: 7100,
      fuelLiters: 160,
      tollCost: 1450,
      foodAllowanceCost: 850,
      maintenanceCost: 0,
      otherCosts: 400, // Hamaliye
    },
    notes: 'Kuzey Marmara ve Anadolu Otoyolu kullanıldı. İrsaliye teslim fişi kaşelendi.',
    invoiceNumber: 'IRS-2026-00412',
    status: 'Tamamlandı',
    date: '2026-10-28',
    createdAt: Date.now() - 4 * 86400000,
  },
  {
    id: 'tr-102',
    plate: '06 TRK 1923',
    driverName: 'Mehmet Demir',
    departureCity: 'Kocaeli (Dilovası)',
    destinationCity: 'İzmir (Kemalpaşa)',
    cargoType: 'Rulo Sac & Profil',
    weightTons: 26.0,
    distanceKm: 450,
    freightRevenue: 34000,
    expenses: {
      fuelCost: 7800,
      fuelLiters: 175,
      tollCost: 2650, // Osmangazi Köprüsü + O-5
      foodAllowanceCost: 900,
      maintenanceCost: 350,
      otherCosts: 600,
    },
    notes: 'Osmangazi Köprüsü geçildi. Yağmurlu hava, rampalarda dikkat edildi.',
    invoiceNumber: 'IRS-2026-00418',
    status: 'Faturalandı',
    date: '2026-10-30',
    createdAt: Date.now() - 2 * 86400000,
  },
  {
    id: 'tr-103',
    plate: '33 MERS 505',
    driverName: 'Cemal Kara',
    departureCity: 'Mersin (Uluslararası Liman)',
    destinationCity: 'Kayseri (Organize Sanayi)',
    cargoType: 'İthal Kimyasal Hammadde (Varil)',
    weightTons: 21.0,
    distanceKm: 310,
    freightRevenue: 24000,
    expenses: {
      fuelCost: 5200,
      fuelLiters: 115,
      tollCost: 420,
      foodAllowanceCost: 650,
      maintenanceCost: 0,
      otherCosts: 300,
    },
    notes: 'Pozantı rampaları geçildi. Araç dinlenme tesisinde mola verildi.',
    invoiceNumber: 'IRS-2026-00425',
    status: 'Yolda',
    date: '2026-11-01',
    createdAt: Date.now() - 5 * 3600000,
  },
];

export function loadTrips(): Trip[] {
  try {
    const raw = localStorage.getItem(TRIPS_KEY);
    if (!raw) {
      saveTrips(INITIAL_TRIPS);
      return INITIAL_TRIPS;
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : INITIAL_TRIPS;
  } catch (err) {
    console.error('Seferler yüklenirken hata:', err);
    return INITIAL_TRIPS;
  }
}

export function saveTrips(trips: Trip[]): void {
  try {
    localStorage.setItem(TRIPS_KEY, JSON.stringify(trips));
  } catch (err) {
    console.error('Seferler kaydedilirken hata:', err);
  }
}

export function calculateTotalExpense(expenses: Trip['expenses']): number {
  return (
    (expenses.fuelCost || 0) +
    (expenses.tollCost || 0) +
    (expenses.foodAllowanceCost || 0) +
    (expenses.maintenanceCost || 0) +
    (expenses.otherCosts || 0)
  );
}

export function calculateNetProfit(trip: Trip): number {
  return (trip.freightRevenue || 0) - calculateTotalExpense(trip.expenses);
}

export function formatTL(amount: number): string {
  return new Intl.NumberFormat('tr-TR', {
    style: 'currency',
    currency: 'TRY',
    maximumFractionDigits: 0,
  }).format(amount);
}

export function generateTripWhatsAppText(trip: Trip): string {
  const totalExp = calculateTotalExpense(trip.expenses);
  const net = calculateNetProfit(trip);
  const margin = trip.freightRevenue > 0 ? ((net / trip.freightRevenue) * 100).toFixed(1) : '0';

  return `🚛 *SEFER BİLGİ PUSULASI* 🚛
━━━━━━━━━━━━━━━━━━━━
📌 *Plaka:* ${trip.plate} ${trip.driverName ? `(${trip.driverName})` : ''}
📍 *Güzergâh:* ${trip.departureCity} ➔ ${trip.destinationCity}
📏 *Mesafe:* ${trip.distanceKm} km | *Tonaj:* ${trip.weightTons} Ton
📦 *Yük Cinsi:* ${trip.cargoType}
📑 *İrsaliye No:* ${trip.invoiceNumber || 'Belirtilmedi'}
📅 *Tarih:* ${trip.date}
🚦 *Durum:* ${trip.status}

💰 *FİNANSAL ÖZET:*
• *Navlun Geliri:* ${formatTL(trip.freightRevenue)}
• *Mazot Gideri:* ${formatTL(trip.expenses.fuelCost)} ${trip.expenses.fuelLiters ? `(${trip.expenses.fuelLiters} Lt)` : ''}
• *Köprü/Otoyol (HGS):* ${formatTL(trip.expenses.tollCost)}
• *Harcırah/Yemek:* ${formatTL(trip.expenses.foodAllowanceCost)}
• *Diğer Giderler:* ${formatTL(trip.expenses.maintenanceCost + trip.expenses.otherCosts)}
────────────────────
🔴 *Toplam Gider:* ${formatTL(totalExp)}
🟢 *NET KÂR:* ${formatTL(net)} (%${margin})
━━━━━━━━━━━━━━━━━━━━
_Yük ve Sefer Defteri Mobil Sistemi ile oluşturuldu._`;
}
