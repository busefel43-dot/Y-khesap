/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Truck,
  Plus,
  Search,
  Filter,
  Calculator,
  Smartphone,
  ShieldCheck,
  Award,
  Download,
  Upload,
  RotateCcw,
  Sparkles,
  ChevronRight,
  ExternalLink,
  BookOpen,
} from 'lucide-react';
import { Trip, TripStatus } from './types/trip';
import { loadTrips, saveTrips, INITIAL_TRIPS } from './utils/storage';
import { admobService, AD_IDS } from './services/admobService';
import { TripCard } from './components/TripCard';
import { TripFormModal } from './components/TripFormModal';
import { DashboardStats } from './components/DashboardStats';
import { FuelCostCalculator } from './components/FuelCostCalculator';
import { AdMobControlPanel } from './components/AdMobControlPanel';
import { AdMobSimulatorBar } from './components/AdMobSimulatorBar';
import { AdMobModal } from './components/AdMobModal';
import { AabExportGuideModal } from './components/AabExportGuideModal';

type ActiveTab = 'trips' | 'calculator' | 'admob' | 'backup';

export default function App() {
  const [trips, setTrips] = useState<Trip[]>([]);
  const [activeTab, setActiveTab] = useState<ActiveTab>('trips');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingTrip, setEditingTrip] = useState<Trip | null>(null);
  const [isAabGuideOpen, setIsAabGuideOpen] = useState(false);

  // AdMob State
  const [adState, setAdState] = useState(admobService.getState());

  useEffect(() => {
    // 1. Initial Trips Loading
    const loaded = loadTrips();
    setTrips(loaded);

    // 2. Initialize Ads as in user's script
    void admobService.initializeAds();

    // 3. Subscribe to AdMob state updates
    const unsub = admobService.subscribe(() => {
      setAdState(admobService.getState());
    });

    // 4. Register DOM event listener hooks for existing DOM buttons if any
    const rewardBtn = document.getElementById('rewardAdBtn');
    const interBtn = document.getElementById('interstitialAdBtn');

    const handleRewardClick = () => {
      void admobService.showRewardedAd();
    };
    const handleInterClick = () => {
      void admobService.showInterstitialAd();
    };

    rewardBtn?.addEventListener('click', handleRewardClick);
    interBtn?.addEventListener('click', handleInterClick);

    return () => {
      unsub();
      rewardBtn?.removeEventListener('click', handleRewardClick);
      interBtn?.removeEventListener('click', handleInterClick);
    };
  }, []);

  const handleSaveTrip = (savedTrip: Trip) => {
    let updated: Trip[];
    const exists = trips.some((t) => t.id === savedTrip.id);
    if (exists) {
      updated = trips.map((t) => (t.id === savedTrip.id ? savedTrip : t));
    } else {
      updated = [savedTrip, ...trips];
    }
    setTrips(updated);
    saveTrips(updated);
  };

  const handleDeleteTrip = (id: string) => {
    const updated = trips.filter((t) => t.id !== id);
    setTrips(updated);
    saveTrips(updated);
  };

  const handleResetSampleData = () => {
    if (confirm('Örnek sefer verileri geri yüklensin mi? Mevcut kayıtlar sıfırlanacaktır.')) {
      setTrips(INITIAL_TRIPS);
      saveTrips(INITIAL_TRIPS);
    }
  };

  const handleExportJson = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(trips, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `sefer_defteri_yedek_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleImportJson = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (Array.isArray(parsed)) {
          setTrips(parsed);
          saveTrips(parsed);
          alert(`${parsed.length} adet sefer başarıyla içe aktarıldı!`);
        } else {
          alert('Geçersiz JSON dosya formatı.');
        }
      } catch (err) {
        alert('Dosya okunurken hata oluştu.');
      }
    };
    reader.readAsText(file);
  };

  // Filter trips
  const filteredTrips = trips.filter((t) => {
    const matchesSearch =
      t.plate.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.departureCity.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.destinationCity.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.cargoType.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (t.driverName && t.driverName.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesStatus = statusFilter === 'all' || t.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans pb-24 selection:bg-amber-500 selection:text-black">
      {/* Top Navbar */}
      <header className="sticky top-0 z-30 border-b border-slate-800 bg-slate-950/85 backdrop-blur-md px-4 sm:px-6 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-tr from-amber-500 to-amber-600 text-slate-950 shadow-lg shadow-amber-500/20 font-black">
              <Truck className="h-6 w-6 text-slate-950" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base sm:text-lg font-extrabold tracking-tight text-white">
                  Yük & Sefer Defteri
                </h1>
                <span
                  className={`hidden sm:inline-flex rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide border ${
                    adState.mode === 'production'
                      ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                      : 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                  }`}
                >
                  AdMob {adState.mode}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block">
                Navlun, Mazot, Net Kâr ve AdMob Reklam Yönetimi
              </p>
            </div>
          </div>

          {/* Quick AdMob Status, AAB Guide & Add Button */}
          <div className="flex items-center gap-2">
            <a
              href="/yuk-sefer-projesi.zip"
              download="yuk-sefer-projesi.zip"
              className="flex items-center gap-1.5 rounded-xl border border-blue-500/30 bg-blue-500/10 hover:bg-blue-500/20 px-3 py-2 text-xs font-bold text-blue-400 transition-colors shadow-sm"
              title="Tüm proje kodlarını tek tıkla ZIP olarak telefona indir"
            >
              <Download className="h-4 w-4" />
              <span className="hidden sm:inline">Projeyi İndir (.ZIP)</span>
              <span className="sm:hidden font-mono">.ZIP</span>
            </a>

            <button
              onClick={() => setIsAabGuideOpen(true)}
              className="flex items-center gap-1.5 rounded-xl border border-emerald-500/30 bg-emerald-500/10 hover:bg-emerald-500/20 px-3 py-2 text-xs font-bold text-emerald-400 transition-colors shadow-sm"
              title="Google Play için AAB (Android App Bundle) çıkarma adımları"
            >
              <Upload className="h-4 w-4" />
              <span className="hidden sm:inline">.AAB Çıkar</span>
              <span className="sm:hidden font-mono">.AAB</span>
            </button>

            <button
              onClick={() => setActiveTab('admob')}
              className="flex items-center gap-1.5 rounded-xl border border-slate-800 bg-slate-900 hover:bg-slate-800 px-3 py-2 text-xs font-semibold text-slate-300 transition-colors"
              title="AdMob & Capacitor Ayarları"
            >
              <Smartphone className="h-4 w-4 text-amber-400" />
              <span className="hidden md:inline">AdMob:</span>
              <span className="text-amber-400 font-mono font-bold">{adState.mode.toUpperCase()}</span>
            </button>

            <button
              onClick={() => {
                setEditingTrip(null);
                setIsFormOpen(true);
              }}
              className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 active:scale-95 px-3.5 sm:px-4 py-2 text-xs sm:text-sm font-bold text-slate-950 shadow-lg shadow-amber-500/20 transition-all"
            >
              <Plus className="h-4 w-4" />
              <span className="hidden xs:inline">Yeni Sefer</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto w-full px-4 sm:px-6 pt-5 space-y-6 flex-1">
        {/* Navigation Tabs */}
        <div className="flex items-center gap-1 overflow-x-auto pb-1 border-b border-slate-800 text-xs sm:text-sm scrollbar-none">
          <button
            onClick={() => setActiveTab('trips')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold transition-all whitespace-nowrap ${
              activeTab === 'trips'
                ? 'bg-amber-500 text-slate-950 shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <BookOpen className="h-4 w-4" />
            <span>Sefer Kayıtları ({trips.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('calculator')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold transition-all whitespace-nowrap ${
              activeTab === 'calculator'
                ? 'bg-amber-500 text-slate-950 shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <Calculator className="h-4 w-4" />
            <span>Mazot & Navlun Hesaplayıcı</span>
          </button>

          <button
            onClick={() => setActiveTab('admob')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold transition-all whitespace-nowrap ${
              activeTab === 'admob'
                ? 'bg-amber-500 text-slate-950 shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <Smartphone className="h-4 w-4" />
            <span>AdMob & Capacitor Merkezi</span>
          </button>

          <button
            onClick={() => setActiveTab('backup')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold transition-all whitespace-nowrap ${
              activeTab === 'backup'
                ? 'bg-amber-500 text-slate-950 shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <Download className="h-4 w-4" />
            <span>Yedekleme & Dışa Aktar</span>
          </button>
        </div>

        {/* Top Financial Dashboard */}
        <DashboardStats
          trips={trips}
          rewardTokens={adState.rewardTokens}
          adMode={adState.mode}
          onOpenAdMob={() => setActiveTab('admob')}
        />

        {/* Tab 1: Seferler (Trips List) */}
        {activeTab === 'trips' && (
          <div className="space-y-4">
            {/* Search and Filter Controls */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
              <div className="relative flex-1">
                <Search className="absolute left-3.5 top-3 h-4 w-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="Plaka, şehir (İstanbul, Ankara...), yük veya şoför ara..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full rounded-xl border border-slate-800 bg-slate-900/90 pl-10 pr-4 py-2.5 text-xs sm:text-sm text-white placeholder-slate-500 focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div className="flex items-center gap-2">
                <Filter className="h-4 w-4 text-slate-400 shrink-0" />
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="rounded-xl border border-slate-800 bg-slate-900 px-3 py-2.5 text-xs text-white focus:border-amber-500 focus:outline-none"
                >
                  <option value="all">Tüm Durumlar</option>
                  <option value="Yolda">Yolda</option>
                  <option value="Teslim Edildi">Teslim Edildi</option>
                  <option value="Faturalandı">Faturalandı</option>
                  <option value="Ödeme Bekliyor">Ödeme Bekliyor</option>
                  <option value="Tamamlandı">Tamamlandı</option>
                </select>
              </div>
            </div>

            {/* Trips Grid */}
            {filteredTrips.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredTrips.map((trip) => (
                  <TripCard
                    key={trip.id}
                    trip={trip}
                    onEdit={(t) => {
                      setEditingTrip(t);
                      setIsFormOpen(true);
                    }}
                    onDelete={handleDeleteTrip}
                  />
                ))}
              </div>
            ) : (
              <div className="rounded-2xl border border-dashed border-slate-800 bg-slate-900/40 p-12 text-center">
                <Truck className="h-12 w-12 text-slate-600 mx-auto mb-3" />
                <h4 className="text-base font-bold text-white mb-1">Kayıtlı Sefer Bulunamadı</h4>
                <p className="text-xs text-slate-400 mb-4 max-w-sm mx-auto">
                  Arama kriterlerinize uygun sefer kaydı yok veya henüz yeni sefer eklemediniz.
                </p>
                <button
                  onClick={() => {
                    setEditingTrip(null);
                    setIsFormOpen(true);
                  }}
                  className="rounded-xl bg-amber-500 px-4 py-2 text-xs font-bold text-slate-950 hover:bg-amber-400 transition-colors"
                >
                  Yeni Sefer Kaydet
                </button>
              </div>
            )}
          </div>
        )}

        {/* Tab 2: Fuel Calculator */}
        {activeTab === 'calculator' && (
          <FuelCostCalculator rewardTokens={adState.rewardTokens} />
        )}

        {/* Tab 3: AdMob Control Panel */}
        {activeTab === 'admob' && (
          <AdMobControlPanel onOpenAabGuide={() => setIsAabGuideOpen(true)} />
        )}

        {/* Tab 4: Backup & Data */}
        {activeTab === 'backup' && (
          <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-6 space-y-6">
            <div>
              <h3 className="text-base font-bold text-white">Veri Yedekleme ve İçe/Dışa Aktarma</h3>
              <p className="text-xs text-slate-400 mt-1">
                Tüm sefer ve navlun kayıtlarınızı JSON dosyası olarak cihazınıza kaydedebilir veya başka bir cihaza yükleyebilirsiniz.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="rounded-xl border border-emerald-500/30 bg-emerald-950/20 p-4 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-400 uppercase mb-1">
                    <Sparkles className="h-4 w-4" />
                    <span>Tüm Projeyi İndir (ZIP)</span>
                  </div>
                  <p className="text-xs text-slate-300 mb-4">
                    AdMob kodları, Capacitor ve Android AAB çıkarıcı dahil tüm kaynak kodları tek paket olarak telefona kaydeder.
                  </p>
                </div>
                <a
                  href="/yuk-sefer-projesi.zip"
                  download="yuk-sefer-projesi.zip"
                  className="w-full flex items-center justify-center gap-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2 text-xs transition-colors shadow-md"
                >
                  <Download className="h-4 w-4" />
                  <span>Projeyi İndir (955 KB)</span>
                </a>
              </div>

              <div className="rounded-xl border border-slate-800 bg-slate-950 p-4 flex flex-col justify-between">
                <div>
                  <h4 className="text-xs font-bold text-white uppercase mb-1">Dışa Aktar (Yedek Al)</h4>
                  <p className="text-xs text-slate-400 mb-4">
                    Kayıtlı {trips.length} seferi JSON formatında indirir.
                  </p>
                </div>
                <button
                  onClick={handleExportJson}
                  className="w-full flex items-center justify-center gap-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold py-2 text-xs transition-colors"
                >
                  <Download className="h-4 w-4" />
                  <span>JSON Olarak İndir</span>
                </button>
              </div>

              <div className="rounded-xl border border-slate-800 bg-slate-950 p-4 flex flex-col justify-between">
                <div>
                  <h4 className="text-xs font-bold text-white uppercase mb-1">İçe Aktar (Geri Yükle)</h4>
                  <p className="text-xs text-slate-400 mb-4">
                    Daha önce kaydedilmiş bir JSON dosyasını sisteme yükler.
                  </p>
                </div>
                <label className="w-full flex items-center justify-center gap-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold py-2 text-xs cursor-pointer transition-colors">
                  <Upload className="h-4 w-4" />
                  <span>Dosya Seç & Yükle</span>
                  <input
                    type="file"
                    accept=".json"
                    onChange={handleImportJson}
                    className="hidden"
                  />
                </label>
              </div>

              <div className="rounded-xl border border-slate-800 bg-slate-950 p-4 flex flex-col justify-between">
                <div>
                  <h4 className="text-xs font-bold text-white uppercase mb-1">Örnek Verileri Yükle</h4>
                  <p className="text-xs text-slate-400 mb-4">
                    Test için gerçekçi 3 adet Türkiye sefer rotasını geri yükler.
                  </p>
                </div>
                <button
                  onClick={handleResetSampleData}
                  className="w-full flex items-center justify-center gap-2 rounded-xl bg-slate-800 hover:bg-rose-950/40 hover:text-rose-300 text-slate-300 font-bold py-2 text-xs border border-slate-700 transition-colors"
                >
                  <RotateCcw className="h-4 w-4" />
                  <span>Varsayılan Verileri Sıfırla</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Hidden container maintaining DOM element hooks if not already present in current tab */}
      {/* Ensures document.getElementById('adStatus'), document.getElementById('rewardAdBtn') and document.getElementById('interstitialAdBtn') always exist in DOM */}
      {activeTab !== 'admob' && (
        <div className="sr-only" aria-hidden="true">
          <span id="adStatus">{adState.statusMessage}</span>
          <button id="rewardAdBtn" onClick={() => void admobService.showRewardedAd()}>
            Ödüllü Reklam
          </button>
          <button id="interstitialAdBtn" onClick={() => void admobService.showInterstitialAd()}>
            Geçiş Reklamı
          </button>
        </div>
      )}

      {/* Trip Form Modal */}
      {isFormOpen && (
        <TripFormModal
          initialTrip={editingTrip}
          onSave={handleSaveTrip}
          onClose={() => {
            setIsFormOpen(false);
            setEditingTrip(null);
          }}
        />
      )}

      {/* Simulated Ad Fullscreen Modal on Web */}
      {adState.simulatedModal !== 'none' && (
        <AdMobModal
          type={adState.simulatedModal}
          adId={
            adState.simulatedModal === 'rewarded'
              ? AD_IDS[adState.mode].rewarded
              : AD_IDS[adState.mode].interstitial
          }
          isTestMode={adState.mode === 'test'}
          onClose={(rewardEarned) => admobService.closeSimulatedModal(rewardEarned)}
        />
      )}

      {/* AAB Export Guide Modal */}
      {isAabGuideOpen && (
        <AabExportGuideModal onClose={() => setIsAabGuideOpen(false)} />
      )}

      {/* Bottom AdMob Adaptive Banner Simulator Bar */}
      <AdMobSimulatorBar
        bannerId={AD_IDS[adState.mode].banner}
        mode={adState.mode}
        isNative={adState.isNative}
        onOpenControlPanel={() => setActiveTab('admob')}
      />
    </div>
  );
}
